from utility import mulitply, divide
from shopping.moreshopping.shoppingcart import buy

print(buy('orange'))
print(mulitply(10,50))
print(divide(10,2))