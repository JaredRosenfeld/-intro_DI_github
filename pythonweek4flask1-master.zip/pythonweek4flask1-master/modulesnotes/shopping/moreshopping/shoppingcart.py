def buy(item):
    cart = []
    cart.append(item)
    print(f"{item} has been added to the cart")
    return cart