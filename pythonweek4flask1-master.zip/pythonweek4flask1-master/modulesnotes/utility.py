def mulitply(number1, number2):
    return number1 * number2

def divide(number1,number2):
    return  number1/number2