def multiply(a,b):
    print(f"{a} x {b}==")
    return a * b
def divide(a,b):
    print(f"{a} % {b}==")
    return a / b
def add(a,b):
    print(f"{a} + {b} == ")
    return a + b
def subtract(a,b):
    print(f"{a} - {b} == ")
    return a - b
