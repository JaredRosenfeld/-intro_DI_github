import calculator as c
import randomint as r
import flask
# 1
print(c.multiply(5,5))
print(c.add(10,50))
print(c.divide(766,2.75))
# 2
print(dir(flask))
# 3
print(r.random_number(55))
# 4